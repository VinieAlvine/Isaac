package resources;

import libraries.Vector2;

public class TireInfo {
	public static Vector2 Tire_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.3);
	public static final double Tire_SPEED = 1/20;
}
