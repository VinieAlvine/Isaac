package resources;
import libraries.Vector2;
public class EquimentInfos {
	
    
	public static Vector2 SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.3);
	public static Vector2 ROCK_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(0.5);
	public static Vector2 DOOR_SIZE = RoomInfos.TILE_SIZE.scalarMultiplication(1.1);
	
	
	
}
